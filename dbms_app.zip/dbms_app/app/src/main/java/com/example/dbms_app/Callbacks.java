package com.example.dbms_app;

public interface Callbacks {
    public void OnGetSuccess();
}
